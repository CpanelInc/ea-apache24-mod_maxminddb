# Contributing

Pull requests are encouraged. Please run `clang-format` on your changes
using before submitting your pull request. You can run this by running
`dev-bin/clang-format-all.sh`.
